package com.jayjay.flowable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlowableApplication {

	public static void main(String[] args) {
		System.out.println("Starting...");
		SpringApplication.run(FlowableApplication.class, args);
	}

}
