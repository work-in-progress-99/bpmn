package com.jayjay.flowable.controller;

import com.jayjay.flowable.entity.ProcessDefinition;
import com.jayjay.flowable.service.ProcessDefinitionService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/processDefinition")
@AllArgsConstructor
public class ProcessDefinitionController {

    private final ProcessDefinitionService processDefinitionService;

    @GetMapping
    public ResponseEntity<?> getProcessDefinitions() {
        return ResponseEntity.ok(processDefinitionService.getProcessDefinitionList());
    }

    @PostMapping
    public ResponseEntity<?> createProcessDefinitions(final @RequestBody ProcessDefinition processDefinition) {
        var response = processDefinitionService.createProcessDefinition(processDefinition);
        return ResponseEntity.ok(response);
    }

}
