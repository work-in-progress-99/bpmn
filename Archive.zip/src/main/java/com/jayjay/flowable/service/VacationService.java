//package com.jayjay.flowable.service;
//
//package com.example.leave.service;
//
//import com.example.leave.entity.VacationLeave;
//import com.example.leave.repository.VacationLeaveRepository;
//import org.flowable.engine.RuntimeService;
//import org.springframework.stereotype.Service;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Service
//public class VacationLeaveService {
//
//    private final VacationLeaveRepository leaveRepository;
//    private final RuntimeService runtimeService;
//
//    public VacationLeaveService(VacationLeaveRepository leaveRepository, RuntimeService runtimeService) {
//        this.leaveRepository = leaveRepository;
//        this.runtimeService = runtimeService;
//    }
//
//    public VacationLeave submitRequest(VacationLeave leave) {
//        VacationLeave saved = leaveRepository.save(leave);
//
//        Map<String, Object> vars = new HashMap<>();
//        vars.put("employeeName", leave.getEmployeeName());
//        vars.put("leaveType", leave.getLeaveType());
//        vars.put("daysRequested", leave.getDaysRequested());
//        vars.put("approved", false); // Default decision
//
//        runtimeService.startProcessInstanceByKey("vacationLeaveProcess", vars);
//        return saved;
//    }
//}
