package com.jayjay.flowable.service;

import com.jayjay.flowable.entity.ProcessDefinition;
import com.jayjay.flowable.repository.ProcessDefinitionRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.flowable.engine.RuntimeService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@AllArgsConstructor
@Slf4j
public class ProcessDefinitionService {

    private final ProcessDefinitionRepository processDefinitionRepository;
    private final RuntimeService runtimeService;

    public String startProcessByKey(final String processDefinitionKey, final Map<String, Object> variables){
        var response = runtimeService.startProcessInstanceById(processDefinitionKey, variables);
        return response.getProcessDefinitionId();
    }

    public List<ProcessDefinition> getProcessDefinitionList() {
        return processDefinitionRepository.findAll();
    }

    public ProcessDefinition createProcessDefinition(final ProcessDefinition processDefinition) {
        var response = processDefinitionRepository.save(processDefinition);
        processDefinition.setId(response.getId());
        log.info(processDefinition.toString());
        return processDefinition;
    }


}
