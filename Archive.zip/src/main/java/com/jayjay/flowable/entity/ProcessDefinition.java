package com.jayjay.flowable.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;

@Entity
@Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ProcessDefinition {
    @Id @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String processDefinitionKey;
    private String name;
}
